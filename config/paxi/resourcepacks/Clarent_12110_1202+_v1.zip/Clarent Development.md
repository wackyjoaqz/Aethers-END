<!--
Pack Name: Excalibur | Clarent Edition
Maintainer: GrandPappyJay
Last Updated: 2025-10-26
-->

# 📂 Clarent Overlay Compatibility Reference

This document tracks all asset changes and Optifine-compatible backports managed by Clarent across Minecraft versions 1.19.2 through 1.21.8, structured by overlay.

---

## ⚙️ Clarent Overlays

### Overlay Excalibur Bugs

🔧 **Edits / Corrections**

- [x] _(**Compat**)_ [Entity] Removed saddle from `camel.png` to align with 1.21.5
- [x] _(**Compat**)_ [Entity] Removed saddle from `donkey.png` to align with 1.21.5
- [x] _(**Compat**)_ [Entity] Removed saddle from `horse.png` to align with 1.21.5 _all variants_
- [x] _(**Compat**)_ [Entity] Removed saddle from `mule.png` to align with 1.21.5 _all variants_
- [x] _(**Compat**)_ [Entity] Added CEM model for `donkey` to align with the current format
- [x] _(**Compat**)_ ~~[Entity] Added CEM model for `horse` to align with the current format~~ _Already in Excalibur_
- [x] _(**Compat**)_ [Entity] Added CEM model for `mule` to align with the current format
- [x] _(**Compat**)_ [Entity] Added CEM model for `skeleton_horse` to align with the current format
- [x] _(**Compat**)_ [Entity] Added CEM model for `zombie_horse` to align with the current format
- [x] _(**Enhancement**)_ [Block] Updated `/textures/block/*_wool.png` to match updated color support
- [x] _(**Enhancement**)_ [Entity] Updated `/textures/entity/banner_base.png` to match updated color support
- [x] _(**Enhancement**)_ [Entity] Updated `/textures/entity/banner/*_wool.png` to match updated color support

🧩 **Mod Support**

- [x] _(**Compat**)_ [polytone] Updated `optifine/color.properties` to reduce conflict with Polytone _found in root `assets`_
- [x] _(**Compat**)_ [polytone] Added `polytone/color.properties` to properly support custom dye colors _found in root `assets`_
- [x] _(**Enhancement**)_ [subtle_effects] Added the missing `biome_color_water_particles` files

### Clarent Overlay (Now supported in `assets` directly)

🔧 **Additions / Alterations**

- [x] [Item] Added a named model variant for `diamond_sword` "Clarent" _CIT support found in overlay 46 & 22_
- [x] [Item] Added a named model variant for `name_tag` "[any name not "Name Tag"]" _CIT support found in overlay 46 & 22_
- [x] [Item] Updated `shield` model for "side carry" style _included CIT shields_
- [x] [Item] Added a`painting` texture for "covered painting"
- [x] [GUI] Reused `edition.png` as "Clarent Edition" banner
- [x] [GUI] Resized `minecraft.png` to allow "Clarent Edition" banner to fit properly
- [x] [GUI] Reused `mojangstudios.png` as "Excalibur | Clarent Edition" loading screen
- [x] [OPTIFINE] Edited `color.properties` to allow for "Clarent Edition" loading screen colors

### Clarent Mod Support

🧩 **Mod Support**

- [x] _(Excalibur)_ [appleskin] 🔙 Backports Excalibur support
- [x] _(Excalibur)_ [entitytexturefeatures] 🔙 Backports Excalibur support
- [x] _(Excalibur)_ [fabric] 🔙 Backports Excalibur support
- [x] _(Excalibur)_ [iris] 🔙 Backports Excalibur support
- [x] _(Excalibur)_ [jade] 🔙 Backports Excalibur support
- [x] _(Excalibur)_ [modmenu] 🔙 Backports Excalibur support
- [x] _(Excalibur)_ [mod_menu] 🔙 Backports Excalibur support
- [x] _(Excalibur)_ [subtle_effects] 🔙 Backports Excalibur support
- [x] _(Clarent)_ [cherishedworlds] Added full support
- [x] _(Clarent)_ [dynamictrees] Added support for "undergrowth" leaves
- [x] _(Clarent)_ [eatinganimation] Added full support _using Excalibur vanilla version_
- [x] _(Clarent)_ [extended_drawers] Added full support
- [x] _(Clarent)_ [fabricskyboxes] Added full support for Excalibur's custom sky
- [x] _(Clarent)_ [fallingleaves] Added full support
- [x] _(Clarent)_ [guardvillagers] Added full support
- [x] _(Clarent)_ [inventorymanagement] Added full support
- [x] _(Clarent)_ [lambdabettergrass] Added full support for standard grassy blocks and fences
- [x] _(Clarent)_ [rprenames] Added full support
- [x] _(Clarent)_ [xaerobetterpvp] Added full support
- [x] _(Clarent)_ [xaerominimap] Added full support for entity icons
- [x] _(Clarent)_ [xaeroworldmap] Added full support

---

## 🧭 Minecraft 1.21

### Overlay 64 (Restore changes from 56–63) — Minecraft: 1.21.8

### Overlay 46 (Restore changes from 47–55) — Minecraft: 1.21.4

🔧 **Significant / Breaking Changes**

- [x] _(Clarent)_ [Texture] Reverted `creaking_heart_awake` back to `creaking_heart_active`
- [x] _(Clarent)_ [Texture] Reverted `creaking_heart_top_awake` back to `creaking_heart_top_active`
- [x] _(Clarent)_ [Texture] Reverted `enchanted_glint_armor.png` back to `enchanted_glint_entity.png`
- [x] _(Clarent)_ [Texture] Reverted `sheep_wool` back to `sheep_fur`
- [x] _(Clarent)_ [Texture] Restored pig saddle texture from `entity/equipment/pig_saddle/` to `entity/pig/pig_saddle.png`
- [x] _(Clarent)_ [Texture] Restored donkey saddle texture from `entity/equipment/donkey_saddle/` to `entity/horse/donkey.png`
- [x] _(Clarent)_ [Texture] Restored mule saddle texture from `entity/equipment/mule_saddle/` to `entity/horse/mule.png`
- [x] _(Clarent)_ [Texture] Restored horse saddle texture from `entity/equipment/horse_saddle/` to `entity/horse/horse.png` (all variants)
- [x] _(Clarent)_ [Texture] Restored skeleton horse saddle texture from `entity/equipment/skeleton_horse_saddle/` to `entity/horse/skeleton_horse.png`
- [x] _(Clarent)_ [Texture] Restored zombie horse saddle texture from `entity/equipment/zombie_horse_saddle/` to `entity/horse/zombie_horse.png`
- [x] _(Clarent)_ [Texture] Restored strider saddle texture from `entity/equipment/strider_saddle/` to `entity/strider/strider_saddle.png`
- [x] _(Clarent)_ [Texture] Reunified pig variants (`temperate_pig`, `cold_pig`, `warm_pig`) back into a single `pig.png`
- [x] _(Clarent)_ [Texture] Reunified cow variants (`temperate_cow`, `cold_cow`, `warm_cow`) back into a single `cow.png`
- [x] _(Clarent)_ [Texture] Reunified chicken variants (`temperate_chicken`, `cold_chicken`, `warm_chicken`) back into a single `chicken.png`
- [x] _(Clarent)_ [Texture] 🔙 Backported `spawn_egg` textures

🎨 **Optifine Feature Changes**

- [x] _(Clarent)_ [CIT] Added support for CIT Item Component system _supported as much as possible_
- [x] _(Clarent)_ [Texture] 🔙 Backported `sheep_wool_undercoat` layer using _Optifine CEM + Random Entity Variants_
- [x] _(Clarent)_ [Texture] 🔙 Backported pig variants (`temperate_pig`, `cold_pig`, `warm_pig`) using _Optifine CEM + Random Entity Variants_
- [x] _(Clarent)_ [Texture] 🔙 Backported cow variants (`temperate_cow`, `cold_cow`, `warm_cow`) using _Optifine CEM + Random Entity Variants_
- [x] _(Clarent)_ [Texture] 🔙 Backported chicken variants (`temperate_chicken`, `cold_chicken`, `warm_chicken`) using _Optifine CEM + Random Entity Variants_

### Overlay 42 (Restore changes from 43–46) — Minecraft: 1.21.3

🔧 **Significant / Breaking Changes**

- [x] _(Clarent)_ [Model] Reverted `cross_emissive` and `flower_pot_cross_emissive` models to legacy `cross` format for torchflower and potted torchflower
- [x] _(Clarent)_ [Model] Reverted Elytra model name from `elytra_broken` back to `broken_elytra`
- [x] _(Clarent)_ [Texture] Reverted `magmacube.png` to legacy UV layout
- [x] _(Clarent)_ [Texture] Reverted Elytra texture name from `elytra_broken.png` back to `broken_elytra.png`
- [x] _(Clarent)_ [UI Texture] Reverted `toast/system.png` to static format (removed nine-slice behavior)
- [x] _(Clarent)_ [UI Texture] Reverted tutorial and advancement sprites (`toast/tutorial`, `advancements/box_*`) to legacy format
- [x] _(Clarent)_ [UI Texture] Reverted empty slot icons from `gui/sprites/container/slot/*.png` to `item/empty_slot_*.png`
- [x] _(Clarent)_ [UI Texture] Reverted loom slot sprites from `container/slot` layout to legacy `loom.png` structure
- [x] _(Clarent)_ [UI Texture] Reverted brewing stand slot sprites to legacy `brewing_stand.png`
- [x] _(Clarent)_ [UI Texture] Reverted horse UI slots (`armor_slot`, `llama_armor_slot`, `saddle_slot`) to legacy `horse.png` structure
- [x] _(Clarent)_ [UI Texture] Reverted empty armor slot icons (`helmet`, `chestplate`, `leggings`, `boots`, `shield`) to legacy paths
- [x] _(Vanilla)_ [Model] No action needed for new `special/standing_sign` and `special/hanging_sign` types (not overridden by Excalibur)

### Overlay 34 (Restore changes from 35–42) — Minecraft: 1.21.1

🔧 **Significant / Breaking Changes**

- [x] _(Clarent)_ [Texture] Restored horse equipment textures from `textures/entity/equipment/*` to `textures/entity/horse/armor/*`
- [x] _(Clarent)_ [Texture] Restored llama equipment textures from `textures/entity/equipment/*` to `textures/entity/llama/decor/*`
- [x] _(Clarent)_ [Texture] Restored wolf equipment textures from `textures/entity/equipment/*` to `textures/entity/wolf/*`
- [x] _(Clarent)_ [Texture] Restored armor textures from `textures/entity/equipment/*` to `textures/models/armor/*`
- [x] _(Clarent)_ [Texture] Restored armor Trim textures from `textures/trims/entity/*` to `textures/trims/models/armor/*`
- [x] _(Clarent)_ [Texture] Reverted elytra texture from `equipment/wings/elytra.png` to `textures/entity/elytra.png`
- [x] _(Clarent)_ [Texture] Reverted bundle item textures to legacy `bundle.png` and `bundle_filled` variants
- [x] _(Clarent)_ [UI Texture] Re-added legacy bundle sprites to `container/bundle/*`
- [x] _(Excalibur)_ [Model] Small dripleaf models (`*_top`, `*_bottom`)
- [x] _(Excalibur)_ [Model] Dragon Egg model and UVs
- [x] _(Excalibur)_ [Texture] Blaze and tropical fish pattern textures
- [x] _(Excalibur)_ [Texture] Arrow projectile textures (`arrow`, `tipped_arrow`, `spectral_arrow`)
- [ ] _(No Action)_ [Model] Comparator and repeater models (`*_on`, `*_locked`, `*_tick`)
- [x] _(Clarent)_ [Texture] 🔙 Backported `spawn_egg` textures

🎨 **Optifine Feature Changes**

- [x] _(Clarent)_ [CEM] Restored legacy entity model for `donkey`
- [x] _(Clarent)_ [CEM] Restored legacy entity model for `horse`
- [x] _(Clarent)_ [CEM] Restored legacy entity model for `mule`
- [x] _(Clarent)_ [CEM] Restored legacy entity model for `skeleton_horse`
- [x] _(Clarent)_ [CEM] Restored legacy entity model for `zombie_horse`
- [x] _(Clarent)_ [CEM] Restored legacy entity model for (`temperate_pig`, `cold_pig`, `warm_pig`) _Random Entity Variants_
- [x] _(Clarent)_ [CEM] Restored legacy entity model for (`temperate_cow`, `cold_cow`, `warm_cow`) _Random Entity Variants_
- [x] _(Clarent)_ [CEM] Restored legacy entity model for (`temperate_chicken`, `cold_chicken`, `warm_chicken`) _Random Entity Variants_

---

## 🧭 Minecraft 1.20

### Overlay 22 (Restore changes from 23–34) — Minecraft: 1.20.4

🔧 **Significant / Breaking Changes**

- [x] _(Clarent)_ [Texture] Renamed `turtle_scute.png` back to `scute.png`
- [x] _(Clarent)_ [Texture] Reunified map icons to `map_icons.png` (deprecated atlas split)
- [x] _(Excalibur)_ [Texture] Reverted `wolf_collar.png` to legacy entity layout
- [x] _(Excalibur)_ [Texture] Reverted `bad_omen.png` to legacy mob effect icon
- [x] _(Excalibur)_ [UI Texture] Reverted GUI separator textures for `footer_separator.png` and `header_separator.png`
- [x] _(Excalibur)_ [UI Texture] Reverted GUI tab sprites for `tab.png`, `tab_highlighted.png`, `tab_selected.png`, `tab_selected_highlighted.png`
- [x] _(Excalibur)_ [UI Texture] Reverted inventory effect background: `effect_background_small.png`
- [x] _(Excalibur)_ [UI Texture] Reverted UI background textures for `light_dirt_background.png` and `options_background.png`
- [x] _(Vanilla)_ [Model] Renamed `turtle_scute.json` model back to `scute.json`
- [x] _(Vanilla)_ [UI Texture] Reverted backup menu sprites for `backup/changes.png`, `backup/changes_highlighted.png`, `backup/restore.png`, `backup/restore_highlighted.png`
- [x] _(Vanilla)_ [UI Texture] Reverted player list sprites for `make_operator_highlighted.png`, `remove_operator_highlighted.png`, `remove_player_highlighted.png`

🎨 **Optifine Feature Changes**

- [x] _(Clarent)_ [CIT] Added support for CIT pre-component format _supported as much as possible_
- [x] _(Clarent)_ [Texture] 🔙 Backported wolf biome variants using _Optifine Random Entity Variants_

🧩 **Mod Support**

- [x] _(Clarent)_ [Fabric] Reverts `creative_buttons.png` to the old format

### Overlay 18 (Restore changes from 19–22) — Minecraft: 1.20.2

🔧 **Significant / Breaking Changes**

- [x] _(Clarent)_ [Texture] Restored `bat.png` to match legacy Bat model
- [x] _(Clarent)_ [Texture] Restored `grass.png` (reverted from `short_grass.png`)
- [x] _(Clarent)_ [Blockstate] Restored `grass.json` blockstate definition
- [x] _(Clarent)_ [Model] Restored `block/grass.json` and `item/grass.json` models

### Overlay 15 (Restore changes from 16–18) — Minecraft: 1.20.1

🔧 **Significant / Breaking Changes**

- [x] _(Clarent)_ [Texture] Restored GUI spritesheets from `textures/gui/sprites/` back to unified sheets (`widgets.png`, etc.)
- [x] _(Clarent)_ [Texture] Moved `realms/` textures back into their original `realms` namespace
- [x] _(Clarent)_ [UI Texture] Reverted `bundle` tooltip background from nine-slice back to static sprite
- [x] _(Clarent)_ [UI Texture] Realms Invite button: restored highlighted texture state
- [x] _(Clarent)_ [UI Texture] Replaced `widget/text_field.png` and `widget/text_field_highlighted.png` with flat versions
- [x] _(Clarent)_ [UI Texture] Replaced `widget/scroller.png` with flat version

🧩 **Mod Support**

- [x] _(**Compat**)_ [entityfeatures] Included files for functionality
- [x] _(**Compat**)_ [iris] Included files for functionality
- [x] _(**Compat**)_ [modmenu] Included files for functionality
- [x] _(**Compat**)_ [subtle_effects] Included files for functionality


---

## 🧪 Snapshots

No snapshot support currently available

---

## 🗝️ Miscellaneous

### The Round Table Pack Version Support

| Pack Format | Minecraft Versions | Excalibur | **Clarent** | FA      | **EFA** |
|-------------|--------------------|-----------|-------------|---------|---------|
| 15          | 1.20.0 → 1.20.1    | 1.21.8    | a           | 1.9.2   | a       |
| 18          | 1.20.2             | 1.21.8    | b           | 1.9.2   | b       |
| 22          | 1.20.3 → 1.20.4    | 1.21.8    | b           | 1.9.2   | b       |
| 34          | 1.20.5 → 1.21.1    | 1.21.8    | b           | 1.9.2   | b       |
| 42          | 1.21.2 → 1.21.3    | 1.21.8    | b           | 1.9.3   | b       |
| 46          | 1.21.4             | 1.21.8    | b           | 1.9.3   | b       |
| 55          | 1.21.5             | 1.21.8    | b           | 1.9.4   | b       |
| 63          | 1.21.6             | 1.21.8    | b           | 1.9.4   | b       |
| 64          | 1.21.8             | 1.21.8    | b           | 1.10.0  | b       |

```Fresh Animations support for 1.21.5 is possible with EFA-b```

## Restoration & Backport Overlays (Main Compatibility System)

| Overlay                         | Pack Formats Active | Restores From Formats | Purpose                                                     |
| ------------------------------- | ------------------- | --------------------- | ----------------------------------------------------------- |
| `overlay_mc_65_compat`          | 18–64               | 56–64                 | Restores format 64 experience, undoes changes made in 56–64 |
| `overlay_mc_46_compat`          | 18–46               | 47–55                 | Restores format 46 experience, undoes changes made in 47–55 |
| `overlay_mc_42_compat`          | 18–42               | 43–46                 | Restores format 42 experience, undoes changes made in 43–46 |
| `overlay_mc_34_compat`          | 18–34               | 35–42                 | Restores format 34 experience, undoes changes made in 35–42 |
| `overlay_mc_22_compat`          | 18–22               | 23–34                 | Restores format 22 experience, undoes changes made in 23–32 |
| `overlay_mc_18_compat`          | 18–18               | 19–22                 | Restores format 18 experience, undoes changes made in 19–22 |
| `overlay_mc_15_compat`          | 15–17               | 16–18                 | Restores pre-overlay behavior (format 15)                   |

---

> 🕯️ _As Excalibur forges ahead, Clarent preserves the past._

---
